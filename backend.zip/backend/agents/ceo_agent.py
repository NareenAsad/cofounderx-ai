from .base_agent import BaseAgent

class CEOAgent(BaseAgent):
    pass
