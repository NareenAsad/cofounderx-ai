from .base_agent import BaseAgent

class ProductAgent(BaseAgent):
    pass
