from .base_agent import BaseAgent

class FinanceAgent(BaseAgent):
    pass
