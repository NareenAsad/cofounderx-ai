from .base_agent import BaseAgent

class BrandingAgent(BaseAgent):
    pass
