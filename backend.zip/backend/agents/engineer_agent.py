from .base_agent import BaseAgent

class EngineerAgent(BaseAgent):
    pass
